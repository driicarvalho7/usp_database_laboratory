/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aula05.oracleinterface;

/**
 *
 * @author junio
 */
public class OracleInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JanelaPrincipal j = new JanelaPrincipal();
        j.ExibeJanelaPrincipal();
    }
}
